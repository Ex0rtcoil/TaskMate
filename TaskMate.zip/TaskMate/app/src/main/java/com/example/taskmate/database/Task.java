
package com.example.taskmate.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;

@Entity(tableName = "tasks")
public class Task {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String title;
    public String subject;
    public String description;
    public String priority;
    public String deadline;

    @ColumnInfo(defaultValue = "0")
    public boolean isCompleted = false;

}
