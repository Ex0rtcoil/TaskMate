package com.example.taskmate;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.taskmate.database.Task;
import com.example.taskmate.database.TaskDatabase;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    Button btnAddTask;

    TextView tvTotalTasks;
    TextView tvPendingTasks;
    TextView tvCompletedTasks;

    LinearLayout layoutTaskList;

    ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connect XML components
        btnAddTask = findViewById(R.id.btnAddTask);

        tvTotalTasks = findViewById(R.id.tvTotalTasks);
        tvPendingTasks = findViewById(R.id.tvPendingTasks);
        tvCompletedTasks = findViewById(R.id.tvCompletedTasks);

        layoutTaskList = findViewById(R.id.layoutTaskList);

        // Open Add Task screen
        btnAddTask.setOnClickListener(v -> {

            Intent intent = new Intent(
                    MainActivity.this,
                    AddTaskActivity.class
            );

            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        loadTasks();
    }

    private void loadTasks() {

        databaseExecutor.execute(() -> {

            TaskDatabase database =
                    TaskDatabase.getDatabase(
                            getApplicationContext()
                    );

            List<Task> tasks =
                    database.taskDao().getAllTasks();

            runOnUiThread(() -> displayTasks(tasks));
        });
    }

    private void displayTasks(List<Task> tasks) {

        // Clear previous task cards
        layoutTaskList.removeAllViews();

        if (tasks.isEmpty()) {

            TextView emptyMessage = new TextView(this);

            emptyMessage.setText(
                    "No tasks yet. Add your first task!"
            );

            emptyMessage.setTextColor(Color.GRAY);
            emptyMessage.setTextSize(14);
            emptyMessage.setGravity(Gravity.CENTER);
            emptyMessage.setPadding(20, 30, 20, 30);
            emptyMessage.setBackgroundColor(Color.WHITE);

            layoutTaskList.addView(emptyMessage);

            tvTotalTasks.setText("0");
            tvPendingTasks.setText("0");
            tvCompletedTasks.setText("0");

            return;
        }

        // Count pending and completed tasks
        int completedCount = 0;
        int pendingCount = 0;

        for (Task t : tasks) {
            if (t.isCompleted) {
                completedCount++;
            } else {
                pendingCount++;
            }
        }

        // Update dashboard
        tvTotalTasks.setText(String.valueOf(tasks.size()));
        tvPendingTasks.setText(String.valueOf(pendingCount));
        tvCompletedTasks.setText(String.valueOf(completedCount));

        // Display saved tasks
        for (Task task : tasks) {

            LinearLayout card = new LinearLayout(this);

            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(24, 20, 24, 20);

            // Custom card background shape drawable & priority colors based on priority and completion
            int backgroundDrawableRes = R.drawable.card_background;
            int priorityColor = Color.rgb(37, 99, 235);

            if (task.isCompleted) {
                backgroundDrawableRes = R.drawable.card_completed;
            } else if ("High".equalsIgnoreCase(task.priority)) {
                backgroundDrawableRes = R.drawable.card_high_priority;
                priorityColor = Color.parseColor("#DC2626"); // Red
            } else if ("Medium".equalsIgnoreCase(task.priority)) {
                backgroundDrawableRes = R.drawable.card_medium_priority;
                priorityColor = Color.parseColor("#D97706"); // Amber
            } else if ("Low".equalsIgnoreCase(task.priority)) {
                backgroundDrawableRes = R.drawable.card_low_priority;
                priorityColor = Color.parseColor("#2563EB"); // Blue
            }

            card.setBackgroundResource(backgroundDrawableRes);
            card.setElevation(4f);

            LinearLayout.LayoutParams cardParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    );

            cardParams.bottomMargin = 16;
            cardParams.leftMargin = 4;
            cardParams.rightMargin = 4;

            card.setLayoutParams(cardParams);

            // Task title
            TextView title = new TextView(this);

            title.setText(task.title);
            title.setTextColor(Color.rgb(15, 23, 42));
            title.setTextSize(18);
            title.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD));
            title.setPadding(0, 0, 0, 4);

            card.addView(title);

            // Subject
            TextView subject = new TextView(this);

            subject.setText("Subject: " + task.subject);
            subject.setTextColor(Color.DKGRAY);
            subject.setTextSize(14);

            card.addView(subject);

            // Priority
            TextView priority = new TextView(this);

            priority.setText("Priority: " + task.priority);
            priority.setTextColor(priorityColor);
            priority.setTextSize(14);

            card.addView(priority);

            // Deadline
            TextView deadline = new TextView(this);

            deadline.setText("Deadline: " + task.deadline);
            deadline.setTextColor(Color.GRAY);
            deadline.setTextSize(14);

            card.addView(deadline);

            // Task Status
            TextView status = new TextView(this);

            if (task.isCompleted) {
                status.setText("Status: Completed");
                status.setTextColor(Color.rgb(22, 163, 74));
            } else {
                status.setText("Status: Pending");
                status.setTextColor(Color.rgb(217, 119, 6));
            }

            status.setTextSize(14);
            card.addView(status);

            // Complete Task Button
            if (!task.isCompleted) {

                Button btnComplete = new Button(this);
                btnComplete.setText("Mark as Complete");

                btnComplete.setOnClickListener(v -> {

                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Complete Task")
                            .setMessage("Have you finished this task?")
                            .setPositiveButton("Yes, Complete", (dialog, which) -> {

                                databaseExecutor.execute(() -> {
                                    task.isCompleted = true;

                                    TaskDatabase database =
                                            TaskDatabase.getDatabase(
                                                    getApplicationContext()
                                            );

                                    database.taskDao().updateTask(task);

                                    runOnUiThread(() -> {
                                        Toast.makeText(
                                                MainActivity.this,
                                                "Task completed successfully!",
                                                Toast.LENGTH_SHORT
                                        ).show();

                                        loadTasks();
                                    });
                                });

                            })
                            .setNegativeButton("Cancel", (dialog, which) -> {
                                dialog.dismiss();
                            })
                            .show();
                });

                card.addView(btnComplete);
            }

            // Edit Task Button
            if (!task.isCompleted) {
                Button btnEdit = new Button(this);
                btnEdit.setText("Edit Task");
                btnEdit.setOnClickListener(v -> {
                    Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
                    intent.putExtra("task_id", task.id);
                    startActivity(intent);
                });
                card.addView(btnEdit);
            }

            // Delete Task Button
            Button btnDelete = new Button(this);
            btnDelete.setText("Delete");
            btnDelete.setTextColor(Color.RED);

            btnDelete.setOnClickListener(v -> {

                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Delete Task")
                        .setMessage("Are you sure you want to delete this task?")
                        .setPositiveButton("Delete", (dialog, which) -> {

                            databaseExecutor.execute(() -> {

                                TaskDatabase database =
                                        TaskDatabase.getDatabase(
                                                getApplicationContext()
                                        );

                                database.taskDao().deleteTask(task);

                                runOnUiThread(() -> {
                                    Toast.makeText(
                                            MainActivity.this,
                                            "Task deleted successfully!",
                                            Toast.LENGTH_SHORT
                                    ).show();

                                    loadTasks();
                                });
                            });

                        })
                        .setNegativeButton("Cancel", (dialog, which) -> {
                            dialog.dismiss();
                        })
                        .show();
            });

            card.addView(btnDelete);

            layoutTaskList.addView(card);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        databaseExecutor.shutdown();
    }
}
