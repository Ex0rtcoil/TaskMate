package com.example.taskmate.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(
        entities = {Task.class},
        version = 2,
        exportSchema = false
)
public abstract class TaskDatabase extends RoomDatabase {

    private static volatile TaskDatabase INSTANCE;

    public abstract TaskDao taskDao();

    static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            database.execSQL(
                    "ALTER TABLE tasks ADD COLUMN isCompleted INTEGER NOT NULL DEFAULT 0"
            );
        }
    };

    public static TaskDatabase getDatabase(Context context) {

        if (INSTANCE == null) {

            synchronized (TaskDatabase.class) {

                if (INSTANCE == null) {

                    INSTANCE = Room.databaseBuilder(
                            context.getApplicationContext(),
                            TaskDatabase.class,
                            "taskmate_database"
                    )
                            .addMigrations(MIGRATION_1_2)
                            .build();

                }
            }
        }

        return INSTANCE;
    }
}
