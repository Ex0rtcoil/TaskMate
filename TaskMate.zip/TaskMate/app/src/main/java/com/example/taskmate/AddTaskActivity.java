
package com.example.taskmate;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.taskmate.database.Task;
import com.example.taskmate.database.TaskDatabase;

import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AddTaskActivity extends AppCompatActivity {

    EditText etTaskTitle, etSubject, etDescription;
    Spinner spPriority;
    Button btnSelectDate, btnSaveTask;
    TextView tvSelectedDate;

    String selectedDate = "";

    ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        // Connect XML components
        etTaskTitle = findViewById(R.id.etTaskTitle);
        etSubject = findViewById(R.id.etSubject);
        etDescription = findViewById(R.id.etDescription);

        spPriority = findViewById(R.id.spPriority);
        btnSelectDate = findViewById(R.id.btnSelectDate);
        btnSaveTask = findViewById(R.id.btnSaveTask);
        tvSelectedDate = findViewById(R.id.tvSelectedDate);

        // Priority options
        String[] priorities = {
                "Low",
                "Medium",
                "High"
        };

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        priorities
                );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spPriority.setAdapter(adapter);

        // Date picker
        btnSelectDate.setOnClickListener(v -> {

            Calendar calendar = Calendar.getInstance();

            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePicker =
                    new DatePickerDialog(
                            AddTaskActivity.this,
                            (view, selectedYear,
                             selectedMonth, selectedDay) -> {

                                selectedDate = String.format(
                                        Locale.getDefault(),
                                        "%04d-%02d-%02d",
                                        selectedYear,
                                        selectedMonth + 1,
                                        selectedDay
                                );

                                tvSelectedDate.setText(
                                        "Deadline: " + selectedDate
                                );
                            },
                            year, month, day
                    );

            datePicker.getDatePicker().setMinDate(
                    calendar.getTimeInMillis()
            );

            datePicker.show();
        });

        // Save button
        btnSaveTask.setOnClickListener(v -> saveTask());
    }

    private void saveTask() {

        String title = etTaskTitle.getText().toString().trim();
        String subject = etSubject.getText().toString().trim();
        String description =
                etDescription.getText().toString().trim();

        String priority =
                spPriority.getSelectedItem().toString();

        // Validate task title
        if (title.isEmpty()) {
            etTaskTitle.setError("Please enter a task title");
            etTaskTitle.requestFocus();
            return;
        }

        // Validate subject
        if (subject.isEmpty()) {
            etSubject.setError("Please enter a subject");
            etSubject.requestFocus();
            return;
        }

        // Validate deadline
        if (selectedDate.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please select a deadline",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Create Task object
        Task task = new Task();

        task.title = title;
        task.subject = subject;
        task.description = description;
        task.priority = priority;
        task.deadline = selectedDate;

        // Save task using Room Database
        btnSaveTask.setEnabled(false);

        databaseExecutor.execute(() -> {

            try {

                TaskDatabase database =
                        TaskDatabase.getDatabase(getApplicationContext());

                database.taskDao().insertTask(task);

                runOnUiThread(() -> {

                    Toast.makeText(
                            AddTaskActivity.this,
                            "Task saved successfully!",
                            Toast.LENGTH_SHORT
                    ).show();

                    finish();
                });

            } catch (Exception e) {

                runOnUiThread(() -> {

                    btnSaveTask.setEnabled(true);

                    Toast.makeText(
                            AddTaskActivity.this,
                            "Failed to save task: " + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        databaseExecutor.shutdown();
    }
}