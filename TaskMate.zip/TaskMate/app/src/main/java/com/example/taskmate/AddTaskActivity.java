package com.example.taskmate;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.taskmate.database.Task;
import com.example.taskmate.database.TaskDatabase;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AddTaskActivity extends AppCompatActivity {

    EditText etTaskTitle, etSubject, etDescription;
    Spinner spPriority;
    Button btnSelectDate, btnSaveTask;
    TextView tvSelectedDate, tvHeaderTitle;

    String selectedDate = "";
    int taskId = -1;

    String originalTitle = "";
    String originalSubject = "";
    String originalDescription = "";
    String originalPriority = "";
    String originalDeadline = "";

    ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        // Request notification permission for Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }

        // Connect XML components
        etTaskTitle = findViewById(R.id.etTaskTitle);
        etSubject = findViewById(R.id.etSubject);
        etDescription = findViewById(R.id.etDescription);

        spPriority = findViewById(R.id.spPriority);
        btnSelectDate = findViewById(R.id.btnSelectDate);
        btnSaveTask = findViewById(R.id.btnSaveTask);
        tvSelectedDate = findViewById(R.id.tvSelectedDate);
        tvHeaderTitle = findViewById(R.id.tvHeaderTitle);

        // Priority options
        String[] priorities = {
                "Low",
                "Medium",
                "High"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_spinner_item,
                priorities
        ) {
            @Override
            public android.view.View getView(int position, android.view.View convertView, android.view.ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                stylePriorityTextView(view, getItem(position));
                return view;
            }

            @Override
            public android.view.View getDropDownView(int position, android.view.View convertView, android.view.ViewGroup parent) {
                TextView view = (TextView) super.getDropDownView(position, convertView, parent);
                stylePriorityTextView(view, getItem(position));
                return view;
            }
        };

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spPriority.setAdapter(adapter);

        // Check if editing existing task
        taskId = getIntent().getIntExtra("task_id", -1);
        if (taskId != -1) {
            if (tvHeaderTitle != null) {
                tvHeaderTitle.setText("Edit Task");
            }
            btnSaveTask.setText("Update Task");

            databaseExecutor.execute(() -> {
                TaskDatabase database = TaskDatabase.getDatabase(getApplicationContext());
                Task existingTask = database.taskDao().getTaskById(taskId);
                if (existingTask != null) {
                    originalTitle = existingTask.title != null ? existingTask.title : "";
                    originalSubject = existingTask.subject != null ? existingTask.subject : "";
                    originalDescription = existingTask.description != null ? existingTask.description : "";
                    originalPriority = existingTask.priority != null ? existingTask.priority : "";
                    originalDeadline = existingTask.deadline != null ? existingTask.deadline : "";

                    runOnUiThread(() -> {
                        etTaskTitle.setText(originalTitle);
                        etSubject.setText(originalSubject);
                        etDescription.setText(originalDescription);
                        selectedDate = originalDeadline;
                        tvSelectedDate.setText("Deadline: " + selectedDate);

                        if (!originalPriority.isEmpty()) {
                            int spinnerPosition = adapter.getPosition(originalPriority);
                            if (spinnerPosition >= 0) {
                                spPriority.setSelection(spinnerPosition);
                            }
                        }
                    });
                }
            });
        }

        // Date picker - exclude present day (start from tomorrow onwards)
        btnSelectDate.setOnClickListener(v -> {

            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DAY_OF_MONTH, 1); // Start from tomorrow

            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePicker =
                    new DatePickerDialog(
                            AddTaskActivity.this,
                            (view, selectedYear,
                             selectedMonth, selectedDay) -> {

                                selectedDate = String.format(
                                        Locale.getDefault(),
                                        "%04d-%02d-%02d",
                                        selectedYear,
                                        selectedMonth + 1,
                                        selectedDay
                                );

                                tvSelectedDate.setText(
                                        "Deadline: " + selectedDate
                                );
                            },
                            year, month, day
                    );

            datePicker.getDatePicker().setMinDate(
                    calendar.getTimeInMillis()
            );

            datePicker.show();
        });

        // Save/Update button
        btnSaveTask.setOnClickListener(v -> saveTask());
    }

    private void saveTask() {

        String title = etTaskTitle.getText().toString().trim();
        String subject = etSubject.getText().toString().trim();
        String description =
                etDescription.getText().toString().trim();

        String priority =
                spPriority.getSelectedItem().toString();

        // Validate task title
        if (title.isEmpty()) {
            etTaskTitle.setError("Please enter a task title");
            etTaskTitle.requestFocus();
            return;
        }

        // Validate subject
        if (subject.isEmpty()) {
            etSubject.setError("Please enter a subject");
            etSubject.requestFocus();
            return;
        }

        // Validate deadline
        if (selectedDate.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please select a deadline",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Schedule notification alarm for exact deadline date
        scheduleTaskNotification(title, description, selectedDate);

        // Determine toast message
        String toastMessage;
        if (taskId != -1) {
            toastMessage = getUpdateMessage(title, subject, description, priority, selectedDate);
        } else {
            toastMessage = "Task saved & reminder scheduled!";
        }

        // Save or update task using Room Database
        btnSaveTask.setEnabled(false);

        final String finalToast = toastMessage;

        databaseExecutor.execute(() -> {

            try {

                TaskDatabase database =
                        TaskDatabase.getDatabase(getApplicationContext());

                if (taskId != -1) {
                    Task task = database.taskDao().getTaskById(taskId);
                    if (task != null) {
                        task.title = title;
                        task.subject = subject;
                        task.description = description;
                        task.priority = priority;
                        task.deadline = selectedDate;
                        database.taskDao().updateTask(task);
                    }
                } else {
                    Task task = new Task();
                    task.title = title;
                    task.subject = subject;
                    task.description = description;
                    task.priority = priority;
                    task.deadline = selectedDate;
                    database.taskDao().insertTask(task);
                }

                runOnUiThread(() -> {

                    Toast.makeText(
                            AddTaskActivity.this,
                            finalToast,
                            Toast.LENGTH_SHORT
                    ).show();

                    finish();
                });

            } catch (Exception e) {

                runOnUiThread(() -> {

                    btnSaveTask.setEnabled(true);

                    Toast.makeText(
                            AddTaskActivity.this,
                            "Failed to save task: " + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
            }
        });
    }

    private String getUpdateMessage(String title, String subject, String description, String priority, String deadline) {
        List<String> changed = new ArrayList<>();
        if (!title.equals(originalTitle)) changed.add("task title");
        if (!subject.equals(originalSubject)) changed.add("subject");
        if (!description.equals(originalDescription)) changed.add("description");
        if (!priority.equals(originalPriority)) changed.add("priority");
        if (!deadline.equals(originalDeadline)) changed.add("calendar");

        if (changed.isEmpty()) {
            return "No changes saved";
        } else if (changed.size() == 1) {
            String field = changed.get(0);
            return field.substring(0, 1).toUpperCase() + field.substring(1) + " saved changes";
        } else if (changed.size() == 2) {
            return capitalize(changed.get(0)) + " and " + changed.get(1) + " saved changes";
        } else {
            StringBuilder sb = new StringBuilder();
            int size = changed.size();
            for (int idx = 0; idx < size; idx++) {
                if (idx > 0) {
                    if (idx == size - 1) {
                        sb.append(" and ");
                    } else {
                        sb.append(", ");
                    }
                }
                sb.append(changed.get(idx));
            }
            String s = sb.toString();
            return s.substring(0, 1).toUpperCase() + s.substring(1) + " saved changes";
        }
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }

    private void stylePriorityTextView(TextView view, String priority) {
        if (view == null || priority == null) return;
        view.setTextSize(16);
        view.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        if ("High".equalsIgnoreCase(priority)) {
            view.setTextColor(android.graphics.Color.parseColor("#DC2626")); // Red
        } else if ("Medium".equalsIgnoreCase(priority)) {
            view.setTextColor(android.graphics.Color.parseColor("#D97706")); // Amber
        } else if ("Low".equalsIgnoreCase(priority)) {
            view.setTextColor(android.graphics.Color.parseColor("#2563EB")); // Blue
        } else {
            view.setTextColor(android.graphics.Color.parseColor("#0F172A"));
        }
    }

    private void scheduleTaskNotification(String taskTitle, String taskDesc, String dateStr) {
        try {
            String[] parts = dateStr.split("-");
            if (parts.length >= 3) {
                int year = Integer.parseInt(parts[0]);
                int month = Integer.parseInt(parts[1]) - 1;
                int day = Integer.parseInt(parts[2]);

                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day, 9, 0, 0); // Exact deadline date at 9:00 AM

                long alarmTime = calendar.getTimeInMillis();

                Intent intent = new Intent(this, TaskNotificationReceiver.class);
                intent.putExtra(TaskNotificationReceiver.EXTRA_TITLE, "Task Due: " + taskTitle);
                intent.putExtra(TaskNotificationReceiver.EXTRA_DESCRIPTION, taskDesc);

                int requestCode = (int) System.currentTimeMillis();
                PendingIntent pendingIntent = PendingIntent.getBroadcast(
                        this,
                        requestCode,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );

                AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                if (alarmManager != null) {
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            if (alarmManager.canScheduleExactAlarms()) {
                                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alarmTime, pendingIntent);
                            } else {
                                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alarmTime, pendingIntent);
                            }
                        } else {
                            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alarmTime, pendingIntent);
                        }
                    } catch (SecurityException e) {
                        alarmManager.set(AlarmManager.RTC_WAKEUP, alarmTime, pendingIntent);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        databaseExecutor.shutdown();
    }
}
