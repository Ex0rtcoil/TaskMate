package com.example.taskmate.database;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.taskmate.R;

import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EditTaskActivity extends AppCompatActivity {

    EditText etEditTitle;
    EditText etEditSubject;
    EditText etEditDescription;
    Spinner spEditPriority;
    Button btnEditSelectDate;
    TextView tvEditSelectedDate;

    Button btnSaveChanges;
    Button btnCancelEdit;

    TaskDatabase database;
    Task currentTask;

    int taskId;
    String selectedDate = "";

    ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_task);

        etEditTitle = findViewById(R.id.etEditTitle);
        etEditSubject = findViewById(R.id.etEditSubject);
        etEditDescription = findViewById(R.id.etEditDescription);
        spEditPriority = findViewById(R.id.spEditPriority);
        btnEditSelectDate = findViewById(R.id.btnEditSelectDate);
        tvEditSelectedDate = findViewById(R.id.tvEditSelectedDate);

        btnSaveChanges = findViewById(R.id.btnSaveChanges);
        btnCancelEdit = findViewById(R.id.btnCancelEdit);

        // Priority options
        String[] priorities = {
                "Low",
                "Medium",
                "High"
        };

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        priorities
                );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spEditPriority.setAdapter(adapter);

        database = TaskDatabase.getDatabase(
                getApplicationContext()
        );

        taskId = getIntent().getIntExtra("TASK_ID", -1);

        if (taskId == -1) {
            Toast.makeText(this, "Invalid task ID",
                    Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadTask();

        // Date picker
        btnEditSelectDate.setOnClickListener(v -> {

            Calendar calendar = Calendar.getInstance();

            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePicker =
                    new DatePickerDialog(
                            EditTaskActivity.this,
                            (view, selectedYear,
                             selectedMonth, selectedDay) -> {

                                selectedDate = String.format(
                                        Locale.getDefault(),
                                        "%04d-%02d-%02d",
                                        selectedYear,
                                        selectedMonth + 1,
                                        selectedDay
                                );

                                tvEditSelectedDate.setText(
                                        "Deadline: " + selectedDate
                                );
                            },
                            year, month, day
                    );

            datePicker.getDatePicker().setMinDate(
                    calendar.getTimeInMillis()
            );

            datePicker.show();
        });

        btnSaveChanges.setOnClickListener(v -> saveChanges());

        btnCancelEdit.setOnClickListener(v -> finish());
    }

    private void loadTask() {

        databaseExecutor.execute(() -> {

            currentTask = database.taskDao().getTaskById(taskId);

            runOnUiThread(() -> {

                if (currentTask == null) {
                    Toast.makeText(this, "Task not found",
                            Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }

                etEditTitle.setText(currentTask.title);
                etEditSubject.setText(currentTask.subject);
                etEditDescription.setText(currentTask.description);

                // Set priority spinner selection
                String priority = currentTask.priority;
                if (priority != null) {
                    ArrayAdapter adapter = (ArrayAdapter) spEditPriority.getAdapter();
                    int position = adapter.getPosition(priority);
                    if (position >= 0) {
                        spEditPriority.setSelection(position);
                    }
                }

                selectedDate = currentTask.deadline;
                if (selectedDate != null && !selectedDate.isEmpty()) {
                    tvEditSelectedDate.setText("Deadline: " + selectedDate);
                }
            });
        });
    }

    private void saveChanges() {

        if (currentTask == null) {
            return;
        }

        String title = etEditTitle.getText().toString().trim();
        String subject = etEditSubject.getText().toString().trim();
        String description = etEditDescription.getText().toString().trim();
        String priority = spEditPriority.getSelectedItem().toString();

        if (title.isEmpty()) {
            etEditTitle.setError("Please enter a task title");
            etEditTitle.requestFocus();
            return;
        }

        if (subject.isEmpty()) {
            etEditSubject.setError("Please enter a subject");
            etEditSubject.requestFocus();
            return;
        }

        if (selectedDate.isEmpty()) {
            Toast.makeText(this,
                    "Please select a deadline",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        currentTask.title = title;
        currentTask.subject = subject;
        currentTask.description = description;
        currentTask.priority = priority;
        currentTask.deadline = selectedDate;

        databaseExecutor.execute(() -> {

            database.taskDao().updateTask(currentTask);

            runOnUiThread(() -> {
                Toast.makeText(this,
                        "Task updated successfully!",
                        Toast.LENGTH_SHORT).show();

                finish();
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        databaseExecutor.shutdown();
    }
}
